package sample.spring.chapter03.bankapp.service;

import sample.spring.chapter03.bankapp.domain.BankStatement;

public interface PersonalBankingService {
	BankStatement getMiniStatement();
}
