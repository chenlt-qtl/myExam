package sample.spring.chapter03.bankapp.domain;

public class Request {

}
